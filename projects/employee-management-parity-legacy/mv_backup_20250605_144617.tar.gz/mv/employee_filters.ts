// /Users/m/Documents/wfm/competitor/naumen/employee-management/src/components/EmployeeFilters.tsx

import React, { useState } from 'react';
import { EmployeeFilters as Filters, Team, Employee } from '../types/employee';

// ========================
// FOUNDATION COMPONENT 3: Advanced Employee Filters
// Based on Chat 6 filtering patterns with enhanced functionality
// ========================

interface EmployeeFiltersProps {
  filters: Filters;
  onFiltersChange: (filters: Filters) => void;
  teams: Team[];
  employees: Employee[];
  isVisible: boolean;
  onToggle: () => void;
}

interface FilterStats {
  totalEmployees: number;
  activeEmployees: number;
  filteredCount: number;
  teamDistribution: { [teamId: string]: number };
  skillDistribution: { [skill: string]: number };
  positionDistribution: { [position: string]: number };
}

const EmployeeFilters: React.FC<EmployeeFiltersProps> = ({ 
  filters, 
  onFiltersChange, 
  teams, 
  employees,
  isVisible,
  onToggle 
}) => {
  const [activeTab, setActiveTab] = useState<'basic' | 'advanced' | 'saved'>('basic');
  const [savedFilters, setSavedFilters] = useState<Array<{id: string, name: string, filters: Filters}>>([
    {
      id: 'active_support',
      name: 'Активные в поддержке',
      filters: {
        search: '',
        team: 't1',
        status: 'active',
        skill: '',
        position: '',
        sortBy: 'performance',
        sortOrder: 'desc',
        showInactive: false
      }
    },
    {
      id: 'high_performers',
      name: 'Высокие показатели',
      filters: {
        search: '',
        team: '',
        status: 'active',
        skill: '',
        position: '',
        sortBy: 'performance',
        sortOrder: 'desc',
        showInactive: false
      }
    }
  ]);

  // Calculate filter statistics
  const calculateStats = (): FilterStats => {
    const stats: FilterStats = {
      totalEmployees: employees.length,
      activeEmployees: employees.filter(emp => emp.status === 'active').length,
      filteredCount: 0,
      teamDistribution: {},
      skillDistribution: {},
      positionDistribution: {}
    };

    // Team distribution
    teams.forEach(team => {
      stats.teamDistribution[team.id] = employees.filter(emp => emp.workInfo.team.id === team.id).length;
    });

    // Skill distribution (top 10 skills)
    const skillCounts: { [skill: string]: number } = {};
    employees.forEach(emp => {
      emp.skills.forEach(skill => {
        skillCounts[skill.name] = (skillCounts[skill.name] || 0) + 1;
      });
    });
    
    // Get top 10 skills
    const topSkills = Object.entries(skillCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10);
    
    topSkills.forEach(([skill, count]) => {
      stats.skillDistribution[skill] = count;
    });

    // Position distribution
    const positionCounts: { [position: string]: number } = {};
    employees.forEach(emp => {
      positionCounts[emp.workInfo.position] = (positionCounts[emp.workInfo.position] || 0) + 1;
    });
    stats.positionDistribution = positionCounts;

    return stats;
  };

  const stats = calculateStats();

  const handleFilterChange = (key: keyof Filters, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const handleResetFilters = () => {
    onFiltersChange({
      search: '',
      team: '',
      status: '',
      skill: '',
      position: '',
      sortBy: 'name',
      sortOrder: 'asc',
      showInactive: false
    });
  };

  const handleSaveFilter = () => {
    const name = prompt('Введите название для сохранения фильтра:');
    if (name) {
      const newFilter = {
        id: `custom_${Date.now()}`,
        name,
        filters: { ...filters }
      };
      setSavedFilters(prev => [...prev, newFilter]);
    }
  };

  const handleLoadFilter = (savedFilter: typeof savedFilters[0]) => {
    onFiltersChange(savedFilter.filters);
  };

  if (!isVisible) {
    return (
      <button
        onClick={onToggle}
        className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all"
      >
        <span className="mr-2 text-lg">🔍</span>
        Расширенные фильтры
        <span className="ml-2 text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
          {Object.values(filters).filter(v => v && v !== 'name' && v !== 'asc' && v !== false).length}
        </span>
      </button>
    );
  }

  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-lg">
      {/* Header */}
      <div className="border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Фильтры сотрудников</h3>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-500">
              Найдено: <span className="font-medium text-gray-900">{stats.totalEmployees}</span> сотрудников
            </span>
            <button
              onClick={onToggle}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="flex mt-4 border-b border-gray-100">
          <button
            onClick={() => setActiveTab('basic')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'basic'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Основные
          </button>
          <button
            onClick={() => setActiveTab('advanced')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'advanced'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Расширенные
          </button>
          <button
            onClick={() => setActiveTab('saved')}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'saved'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Сохраненные
            <span className="ml-1 text-xs bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded-full">
              {savedFilters.length}
            </span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {activeTab === 'basic' && (
          <div className="space-y-6">
            {/* Search */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Поиск</label>
              <input
                type="text"
                placeholder="Поиск по имени, email, ID..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              />
            </div>

            {/* Team and Status */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Команда
                  <span className="ml-1 text-xs text-gray-500">({Object.keys(stats.teamDistribution).length})</span>
                </label>
                <select
                  value={filters.team}
                  onChange={(e) => handleFilterChange('team', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                >
                  <option value="">Все команды</option>
                  {teams.map(team => (
                    <option key={team.id} value={team.id}>
                      {team.name} ({stats.teamDistribution[team.id] || 0})
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Статус</label>
                <select
                  value={filters.status}
                  onChange={(e) => handleFilterChange('status', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                >
                  <option value="">Все статусы</option>
                  <option value="active">Активные ({employees.filter(e => e.status === 'active').length})</option>
                  <option value="vacation">В отпуске ({employees.filter(e => e.status === 'vacation').length})</option>
                  <option value="probation">На испытательном ({employees.filter(e => e.status === 'probation').length})</option>
                  <option value="inactive">Неактивные ({employees.filter(e => e.status === 'inactive').length})</option>
                  <option value="terminated">Уволенные ({employees.filter(e => e.status === 'terminated').length})</option>
                </select>
              </div>
            </div>

            {/* Sorting */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Сортировка</label>
                <select
                  value={filters.sortBy}
                  onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                >
                  <option value="name">По имени</option>
                  <option value="position">По должности</option>
                  <option value="team">По команде</option>
                  <option value="hireDate">По дате найма</option>
                  <option value="performance">По производительности</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Порядок</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleFilterChange('sortOrder', 'asc')}
                    className={`flex-1 px-3 py-2 text-sm font-medium rounded-lg transition-all ${
                      filters.sortOrder === 'asc'
                        ? 'bg-blue-100 text-blue-700 border border-blue-300'
                        : 'bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200'
                    }`}
                  >
                    ↑ По возрастанию
                  </button>
                  <button
                    onClick={() => handleFilterChange('sortOrder', 'desc')}
                    className={`flex-1 px-3 py-2 text-sm font-medium rounded-lg transition-all ${
                      filters.sortOrder === 'desc'
                        ? 'bg-blue-100 text-blue-700 border border-blue-300'
                        : 'bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200'
                    }`}
                  >
                    ↓ По убыванию
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'advanced' && (
          <div className="space-y-6">
            {/* Skills and Position */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Навыки
                  <span className="ml-1 text-xs text-gray-500">({Object.keys(stats.skillDistribution).length})</span>
                </label>
                <input
                  type="text"
                  placeholder="Поиск по навыкам..."
                  value={filters.skill}
                  onChange={(e) => handleFilterChange('skill', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                />
                
                {/* Popular Skills */}
                <div className="mt-2 space-y-1">
                  <p className="text-xs text-gray-500 font-medium">Популярные навыки:</p>
                  <div className="flex flex-wrap gap-1">
                    {Object.entries(stats.skillDistribution).slice(0, 6).map(([skill, count]) => (
                      <button
                        key={skill}
                        onClick={() => handleFilterChange('skill', skill)}
                        className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors"
                      >
                        {skill} ({count})
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Должность
                  <span className="ml-1 text-xs text-gray-500">({Object.keys(stats.positionDistribution).length})</span>
                </label>
                <input
                  type="text"
                  placeholder="Поиск по должности..."
                  value={filters.position}
                  onChange={(e) => handleFilterChange('position', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                />
                
                {/* Popular Positions */}
                <div className="mt-2 space-y-1">
                  <p className="text-xs text-gray-500 font-medium">Должности:</p>
                  <div className="space-y-1">
                    {Object.entries(stats.positionDistribution).map(([position, count]) => (
                      <button
                        key={position}
                        onClick={() => handleFilterChange('position', position)}
                        className="block w-full text-left px-2 py-1 text-xs bg-gray-50 text-gray-700 rounded hover:bg-blue-50 hover:text-blue-700 transition-colors"
                      >
                        {position} ({count})
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Advanced Options */}
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">Показать неактивных сотрудников</p>
                  <p className="text-sm text-gray-600">Включить в результаты деактивированных и уволенных</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.showInactive}
                    onChange={(e) => handleFilterChange('showInactive', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>

            {/* Performance Filters (Future enhancement) */}
            <div className="p-4 border-2 border-dashed border-gray-200 rounded-lg text-center">
              <div className="text-gray-400 text-4xl mb-2">📊</div>
              <p className="text-sm text-gray-500 font-medium">Фильтры по производительности</p>
              <p className="text-xs text-gray-400">Будут добавлены в следующем обновлении</p>
            </div>
          </div>
        )}

        {activeTab === 'saved' && (
          <div className="space-y-4">
            {/* Current Filter Save */}
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-blue-900">Текущий фильтр</p>
                  <p className="text-sm text-blue-700">
                    {Object.values(filters).filter(v => v && v !== 'name' && v !== 'asc' && v !== false).length} активных параметров
                  </p>
                </div>
                <button
                  onClick={handleSaveFilter}
                  className="px-3 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
                >
                  Сохранить
                </button>
              </div>
            </div>

            {/* Saved Filters */}
            <div className="space-y-3">
              <p className="text-sm font-medium text-gray-700">Сохраненные фильтры:</p>
              
              {savedFilters.map((savedFilter) => (
                <div key={savedFilter.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div>
                    <p className="font-medium text-gray-900">{savedFilter.name}</p>
                    <p className="text-sm text-gray-600">
                      {Object.values(savedFilter.filters).filter(v => v && v !== 'name' && v !== 'asc' && v !== false).length} параметров
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleLoadFilter(savedFilter)}
                      className="px-3 py-1 bg-blue-100 text-blue-700 rounded text-sm hover:bg-blue-200 transition-colors"
                    >
                      Применить
                    </button>
                    <button
                      onClick={() => setSavedFilters(prev => prev.filter(f => f.id !== savedFilter.id))}
                      className="px-3 py-1 bg-red-100 text-red-700 rounded text-sm hover:bg-red-200 transition-colors"
                    >
                      Удалить
                    </button>
                  </div>
                </div>
              ))}
              
              {savedFilters.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <div className="text-4xl mb-2">🔖</div>
                  <p>Нет сохраненных фильтров</p>
                  <p className="text-sm">Сохраните текущий фильтр для быстрого доступа</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200 p-4 bg-gray-50 rounded-b-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span>Всего: <strong>{stats.totalEmployees}</strong></span>
            <span>Активных: <strong>{stats.activeEmployees}</strong></span>
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={handleResetFilters}
              className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 transition-colors"
            >
              Сбросить все
            </button>
            <button
              onClick={onToggle}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
            >
              Применить фильтры
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeFilters;