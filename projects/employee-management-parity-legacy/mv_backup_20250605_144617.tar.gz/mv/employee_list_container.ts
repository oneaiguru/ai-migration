// /Users/m/Documents/wfm/competitor/naumen/employee-management/src/components/EmployeeListContainer.tsx

import React, { useState, useEffect } from 'react';
import { Employee, Team, EmployeeFilters, BulkAction, ViewModes } from '../types/employee';

// ========================
// FOUNDATION COMPONENT 1: Employee List Container
// Based on successful patterns from Chat 6 (PersonalSchedule.tsx style)
// ========================

interface EmployeeListContainerProps {
  teamId?: string;
  showAll?: boolean;
}

const EmployeeListContainer: React.FC<EmployeeListContainerProps> = ({ 
  teamId, 
  showAll = true 
}) => {
  // State management following Chat 6 patterns
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewModes['current']>('grid');
  const [selectedEmployees, setSelectedEmployees] = useState<Set<string>>(new Set());
  const [filters, setFilters] = useState<EmployeeFilters>({
    search: '',
    team: teamId || '',
    status: '',
    skill: '',
    position: '',
    sortBy: 'name',
    sortOrder: 'asc',
    showInactive: false
  });
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  // Mock data with realistic structure (following Chat 6 data patterns)
  const generateMockEmployees = (): Employee[] => {
    return [
      {
        id: 'emp_001',
        employeeId: 'EMP001',
        personalInfo: {
          firstName: 'Динара',
          lastName: 'Абдуллаева',
          email: 'dinara.abdullaeva@company.com',
          phone: '+996555123456',
          photo: 'https://i.pravatar.cc/150?img=1',
          emergencyContact: {
            name: 'Марат Абдуллаев',
            phone: '+996555123457',
            relationship: 'супруг'
          }
        },
        workInfo: {
          position: 'Старший оператор',
          team: { 
            id: 't1', 
            name: 'Группа поддержки', 
            color: '#3b82f6',
            managerId: 'mgr_001',
            memberCount: 12,
            targetUtilization: 0.85
          },
          manager: 'Иванов И.И.',
          hireDate: new Date('2022-03-15'),
          contractType: 'full-time',
          salary: 45000,
          workLocation: 'Офис Бишкек',
          department: 'Клиентская поддержка'
        },
        skills: [
          { 
            id: 's1', 
            name: 'Консультирование клиентов', 
            level: 5, 
            category: 'communication', 
            verified: true,
            lastAssessed: new Date('2024-01-15'),
            assessor: 'Иванов И.И.',
            certificationRequired: false
          },
          { 
            id: 's2', 
            name: 'CRM система', 
            level: 4, 
            category: 'technical', 
            verified: true,
            lastAssessed: new Date('2024-02-01'),
            assessor: 'Петров А.В.',
            certificationRequired: true
          },
          { 
            id: 's3', 
            name: 'Английский язык', 
            level: 3, 
            category: 'language', 
            verified: false,
            lastAssessed: new Date('2023-12-10'),
            assessor: 'Смирнова Л.К.',
            certificationRequired: false
          }
        ],
        status: 'active',
        preferences: {
          preferredShifts: ['morning', 'day'],
          notifications: {
            email: true,
            sms: true,
            push: true,
            scheduleChanges: true,
            announcements: true,
            reminders: true
          },
          language: 'ru',
          workingHours: {
            start: '08:00',
            end: '17:00'
          }
        },
        performance: {
          averageHandleTime: 7.5,
          callsPerHour: 12.5,
          qualityScore: 94,
          adherenceScore: 87,
          customerSatisfaction: 4.8,
          lastEvaluation: new Date('2024-01-30')
        },
        certifications: [
          {
            id: 'cert_001',
            name: 'Сертификат клиентского сервиса',
            issuer: 'Учебный центр КЦ',
            issueDate: new Date('2023-06-15'),
            expirationDate: new Date('2025-06-15'),
            status: 'active'
          }
        ],
        metadata: {
          createdAt: new Date('2022-03-15'),
          updatedAt: new Date('2024-02-15'),
          createdBy: 'admin_001',
          lastModifiedBy: 'mgr_001',
          lastLogin: new Date('2024-02-14T09:30:00')
        }
      },
      {
        id: 'emp_002',
        employeeId: 'EMP002',
        personalInfo: {
          firstName: 'Мария',
          lastName: 'Азикова',
          email: 'maria.azikova@company.com',
          phone: '+996555654321',
          photo: 'https://i.pravatar.cc/150?img=2'
        },
        workInfo: {
          position: 'Оператор',
          team: { 
            id: 't1', 
            name: 'Группа поддержки', 
            color: '#3b82f6',
            managerId: 'mgr_001',
            memberCount: 12,
            targetUtilization: 0.85
          },
          manager: 'Иванов И.И.',
          hireDate: new Date('2023-01-20'),
          contractType: 'full-time',
          workLocation: 'Офис Бишкек',
          department: 'Клиентская поддержка'
        },
        skills: [
          { 
            id: 's4', 
            name: 'Телефонные продажи', 
            level: 4, 
            category: 'communication', 
            verified: true,
            lastAssessed: new Date('2024-01-10'),
            assessor: 'Иванов И.И.',
            certificationRequired: false
          },
          { 
            id: 's5', 
            name: 'База данных', 
            level: 3, 
            category: 'technical', 
            verified: true,
            lastAssessed: new Date('2023-12-15'),
            assessor: 'Петров А.В.',
            certificationRequired: false
          }
        ],
        status: 'active',
        preferences: {
          preferredShifts: ['day', 'evening'],
          notifications: {
            email: true,
            sms: false,
            push: true,
            scheduleChanges: true,
            announcements: false,
            reminders: true
          },
          language: 'ru',
          workingHours: {
            start: '09:00',
            end: '18:00'
          }
        },
        performance: {
          averageHandleTime: 8.2,
          callsPerHour: 10.8,
          qualityScore: 89,
          adherenceScore: 92,
          customerSatisfaction: 4.6,
          lastEvaluation: new Date('2024-01-25')
        },
        certifications: [],
        metadata: {
          createdAt: new Date('2023-01-20'),
          updatedAt: new Date('2024-02-10'),
          createdBy: 'admin_001',
          lastModifiedBy: 'mgr_001',
          lastLogin: new Date('2024-02-14T08:45:00')
        }
      },
      {
        id: 'emp_003',
        employeeId: 'EMP003',
        personalInfo: {
          firstName: 'Данара',
          lastName: 'Акашева',
          email: 'danara.akasheva@company.com',
          phone: '+996555789123',
          photo: 'https://i.pravatar.cc/150?img=3'
        },
        workInfo: {
          position: 'Старший оператор продаж',
          team: { 
            id: 't2', 
            name: 'Группа продаж', 
            color: '#10b981',
            managerId: 'mgr_002',
            memberCount: 8,
            targetUtilization: 0.90
          },
          manager: 'Петрова А.В.',
          hireDate: new Date('2021-06-10'),
          contractType: 'full-time',
          workLocation: 'Офис Бишкек',
          department: 'Продажи'
        },
        skills: [
          { 
            id: 's6', 
            name: 'Активные продажи', 
            level: 5, 
            category: 'communication', 
            verified: true,
            lastAssessed: new Date('2024-01-20'),
            assessor: 'Петрова А.В.',
            certificationRequired: true
          },
          { 
            id: 's7', 
            name: 'Аналитика продаж', 
            level: 4, 
            category: 'technical', 
            verified: true,
            lastAssessed: new Date('2024-01-05'),
            assessor: 'Козлов В.М.',
            certificationRequired: false
          }
        ],
        status: 'vacation',
        preferences: {
          preferredShifts: ['morning'],
          notifications: {
            email: true,
            sms: true,
            push: true,
            scheduleChanges: true,
            announcements: true,
            reminders: true
          },
          language: 'ru',
          workingHours: {
            start: '08:00',
            end: '17:00'
          }
        },
        performance: {
          averageHandleTime: 12.5,
          callsPerHour: 15.2,
          qualityScore: 96,
          adherenceScore: 78,
          customerSatisfaction: 4.9,
          lastEvaluation: new Date('2024-01-15')
        },
        certifications: [
          {
            id: 'cert_002',
            name: 'Сертификат продаж',
            issuer: 'Институт продаж',
            issueDate: new Date('2022-09-10'),
            expirationDate: new Date('2025-09-10'),
            status: 'active'
          }
        ],
        metadata: {
          createdAt: new Date('2021-06-10'),
          updatedAt: new Date('2024-02-01'),
          createdBy: 'admin_001',
          lastModifiedBy: 'mgr_002',
          lastLogin: new Date('2024-02-08T16:20:00')
        }
      }
    ];
  };

  // Load employees (following Chat 6 async patterns)
  useEffect(() => {
    const loadEmployees = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1200));
        
        const mockData = generateMockEmployees();
        setEmployees(mockData);
      } catch (err) {
        setError('Ошибка загрузки данных сотрудников. Попробуйте еще раз.');
        console.error('Employee loading error:', err);
      } finally {
        setLoading(false);
      }
    };

    loadEmployees();
  }, [teamId]);

  // Filter and sort employees (following Chat 6 filter patterns)
  const filteredAndSortedEmployees = React.useMemo(() => {
    let filtered = employees.filter(emp => {
      const matchesSearch = 
        emp.personalInfo.firstName.toLowerCase().includes(filters.search.toLowerCase()) ||
        emp.personalInfo.lastName.toLowerCase().includes(filters.search.toLowerCase()) ||
        emp.workInfo.position.toLowerCase().includes(filters.search.toLowerCase()) ||
        emp.workInfo.team.name.toLowerCase().includes(filters.search.toLowerCase()) ||
        emp.employeeId.toLowerCase().includes(filters.search.toLowerCase()) ||
        emp.personalInfo.email.toLowerCase().includes(filters.search.toLowerCase());
      
      const matchesTeam = !filters.team || emp.workInfo.team.id === filters.team;
      const matchesStatus = !filters.status || emp.status === filters.status;
      const matchesPosition = !filters.position || emp.workInfo.position.includes(filters.position);
      const matchesSkill = !filters.skill || emp.skills.some(skill => 
        skill.name.toLowerCase().includes(filters.skill.toLowerCase())
      );
      const statusFilter = filters.showInactive || emp.status !== 'inactive';
      
      return matchesSearch && matchesTeam && matchesStatus && matchesPosition && matchesSkill && statusFilter;
    });

    // Sorting
    filtered.sort((a, b) => {
      let compareValue = 0;
      
      switch (filters.sortBy) {
        case 'name':
          compareValue = `${a.personalInfo.firstName} ${a.personalInfo.lastName}`
            .localeCompare(`${b.personalInfo.firstName} ${b.personalInfo.lastName}`);
          break;
        case 'position':
          compareValue = a.workInfo.position.localeCompare(b.workInfo.position);
          break;
        case 'team':
          compareValue = a.workInfo.team.name.localeCompare(b.workInfo.team.name);
          break;
        case 'hireDate':
          compareValue = a.workInfo.hireDate.getTime() - b.workInfo.hireDate.getTime();
          break;
        case 'performance':
          compareValue = b.performance.qualityScore - a.performance.qualityScore;
          break;
        default:
          compareValue = 0;
      }
      
      return filters.sortOrder === 'desc' ? -compareValue : compareValue;
    });

    return filtered;
  }, [employees, filters]);

  // Selection handlers (following Chat 6 selection patterns)
  const handleSelectEmployee = (employeeId: string) => {
    const newSelected = new Set(selectedEmployees);
    if (newSelected.has(employeeId)) {
      newSelected.delete(employeeId);
    } else {
      newSelected.add(employeeId);
    }
    setSelectedEmployees(newSelected);
    setShowBulkActions(newSelected.size > 0);
  };

  const handleSelectAll = () => {
    if (selectedEmployees.size === filteredAndSortedEmployees.length && filteredAndSortedEmployees.length > 0) {
      setSelectedEmployees(new Set());
      setShowBulkActions(false);
    } else {
      const allIds = new Set(filteredAndSortedEmployees.map(emp => emp.id));
      setSelectedEmployees(allIds);
      setShowBulkActions(true);
    }
  };

  const handleBulkAction = (action: BulkAction['type']) => {
    console.log(`Bulk action: ${action} for employees:`, Array.from(selectedEmployees));
    // Implementation will be added in subsequent prompts
  };

  // Loading state (following Chat 6 loading patterns)
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <div className="space-y-2">
            <p className="text-lg font-medium text-gray-900">Загрузка сотрудников...</p>
            <p className="text-sm text-gray-600">Получение данных из системы</p>
          </div>
        </div>
      </div>
    );
  }

  // Error state (following Chat 6 error patterns)
  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
        <div className="text-red-600 text-6xl mb-4">⚠️</div>
        <h3 className="text-lg font-semibold text-red-900 mb-2">Ошибка загрузки данных</h3>
        <p className="text-red-700 mb-4">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
        >
          Попробовать снова
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Header Section - Following Chat 6 header patterns */}
      <div className="border-b border-gray-200 p-6">
        <div className="flex flex-col xl:flex-row xl:justify-between xl:items-start mb-6">
          <div className="mb-4 xl:mb-0">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Управление сотрудниками</h1>
            <p className="text-gray-600">
              Полное управление персоналом контакт-центра с детальной информацией о навыках и производительности
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button className="inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all">
              <span className="mr-2 text-lg">👤</span>
              Добавить сотрудника
            </button>
            
            <button className="inline-flex items-center justify-center px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all">
              <span className="mr-2 text-lg">📤</span>
              Экспорт
            </button>
            
            <button className="inline-flex items-center justify-center px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all">
              <span className="mr-2 text-lg">📥</span>
              Импорт
            </button>
          </div>
        </div>
        
        {/* Search and Quick Filters */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-4">
          <div className="lg:col-span-5 relative">
            <input
              type="text"
              placeholder="Поиск по имени, должности, ID, команде, email..."
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all placeholder-gray-400"
            />
            <span className="absolute left-3 top-3.5 text-gray-400 text-lg">🔍</span>
            {filters.search && (
              <button
                onClick={() => setFilters(prev => ({ ...prev, search: '' }))}
                className="absolute right-3 top-3.5 text-gray-400 hover:text-gray-600 transition-colors"
              >
                ✕
              </button>
            )}
          </div>
          
          <div className="lg:col-span-2">
            <select 
              value={filters.team}
              onChange={(e) => setFilters(prev => ({ ...prev, team: e.target.value }))}
              className="w-full px-3 py-3 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
            >
              <option value="">Все команды</option>
              <option value="t1">Группа поддержки</option>
              <option value="t2">Группа продаж</option>
            </select>
          </div>
          
          <div className="lg:col-span-2">
            <select
              value={filters.status}
              onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
              className="w-full px-3 py-3 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
            >
              <option value="">Все статусы</option>
              <option value="active">Активные</option>
              <option value="vacation">В отпуске</option>
              <option value="probation">На испытательном</option>
              <option value="inactive">Неактивные</option>
            </select>
          </div>
          
          <div className="lg:col-span-2">
            <select
              value={filters.sortBy}
              onChange={(e) => setFilters(prev => ({ ...prev, sortBy: e.target.value as any }))}
              className="w-full px-3 py-3 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
            >
              <option value="name">По имени</option>
              <option value="position">По должности</option>
              <option value="team">По команде</option>
              <option value="hireDate">По дате найма</option>
              <option value="performance">По производительности</option>
            </select>
          </div>
          
          <div className="lg:col-span-1">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`w-full px-3 py-3 border rounded-lg text-sm font-medium transition-all ${
                showFilters 
                  ? 'bg-blue-50 border-blue-300 text-blue-700' 
                  : 'border-gray-300 text-gray-700 hover:bg-gray-50'
              }`}
            >
              Фильтры
            </button>
          </div>
        </div>
        
        {/* Advanced Filters Panel */}
        {showFilters && (
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Навыки</label>
                <input
                  type="text"
                  placeholder="Поиск по навыкам..."
                  value={filters.skill}
                  onChange={(e) => setFilters(prev => ({ ...prev, skill: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Должность</label>
                <input
                  type="text"
                  placeholder="Поиск по должности..."
                  value={filters.position}
                  onChange={(e) => setFilters(prev => ({ ...prev, position: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div className="flex items-end">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={filters.showInactive}
                    onChange={(e) => setFilters(prev => ({ ...prev, showInactive: e.target.checked }))}
                    className="rounded text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">Показать неактивных</span>
                </label>
              </div>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => setFilters({
                  search: '',
                  team: '',
                  status: '',
                  skill: '',
                  position: '',
                  sortBy: 'name',
                  sortOrder: 'asc',
                  showInactive: false
                })}
                className="px-3 py-2 text-sm text-gray-600 hover:text-gray-800 transition-colors"
              >
                Сбросить фильтры
              </button>
            </div>
          </div>
        )}
        
        {/* View Mode and Statistics */}
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="flex border border-gray-300 rounded-lg overflow-hidden">
              <button
                onClick={() => setViewMode('grid')}
                className={`px-4 py-2 text-sm font-medium transition-all ${
                  viewMode === 'grid' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                <span className="text-lg">⋯</span>
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`px-4 py-2 text-sm font-medium border-l transition-all ${
                  viewMode === 'table' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                <span className="text-lg">☰</span>
              </button>
              <button
                onClick={() => setViewMode('cards')}
                className={`px-4 py-2 text-sm font-medium border-l transition-all ${
                  viewMode === 'cards' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                <span className="text-lg">📋</span>
              </button>
            </div>
            
            <div className="text-sm text-gray-600">
              Показано <span className="font-semibold text-gray-900">{filteredAndSortedEmployees.length}</span> из <span className="font-semibold text-gray-900">{employees.length}</span> сотрудников
            </div>
          </div>
          
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
              <span className="text-gray-600">
                Активные: <span className="font-medium text-gray-900">{employees.filter(e => e.status === 'active').length}</span>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <span className="text-gray-600">
                В отпуске: <span className="font-medium text-gray-900">{employees.filter(e => e.status === 'vacation').length}</span>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500"></div>
              <span className="text-gray-600">
                На испытательном: <span className="font-medium text-gray-900">{employees.filter(e => e.status === 'probation').length}</span>
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Bulk Actions Bar - Following Chat 6 selection patterns */}
      {showBulkActions && (
        <div className="bg-blue-50 border-b border-blue-200 px-6 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-blue-900">
                Выбрано: {selectedEmployees.size} сотрудник(ов)
              </span>
              <button
                onClick={() => {
                  setSelectedEmployees(new Set());
                  setShowBulkActions(false);
                }}
                className="text-sm text-blue-700 hover:text-blue-800 transition-colors"
              >
                Снять выделение
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              <button 
                onClick={() => handleBulkAction('change-team')}
                className="px-3 py-2 bg-white border border-blue-300 text-blue-700 rounded-lg text-sm font-medium hover:bg-blue-50 transition-colors"
              >
                Изменить команду
              </button>
              <button 
                onClick={() => handleBulkAction('bulk-edit')}
                className="px-3 py-2 bg-white border border-blue-300 text-blue-700 rounded-lg text-sm font-medium hover:bg-blue-50 transition-colors"
              >
                Массовое редактирование
              </button>
              <button 
                onClick={() => handleBulkAction('export-selected')}
                className="px-3 py-2 bg-white border border-blue-300 text-blue-700 rounded-lg text-sm font-medium hover:bg-blue-50 transition-colors"
              >
                Экспорт выбранных
              </button>
              <button 
                onClick={() => handleBulkAction('deactivate')}
                className="px-3 py-2 bg-red-100 border border-red-300 text-red-700 rounded-lg text-sm font-medium hover:bg-red-200 transition-colors"
              >
                Деактивировать
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Content Area */}
      <div className="p-6">
        {viewMode === 'grid' ? (
          <EmployeeGrid 
            employees={filteredAndSortedEmployees}
            selectedEmployees={selectedEmployees}
            onSelectEmployee={handleSelectEmployee}
            onSelectAll={handleSelectAll}
          />
        ) : viewMode === 'table' ? (
          <EmployeeTable 
            employees={filteredAndSortedEmployees}
            selectedEmployees={selectedEmployees}
            onSelectEmployee={handleSelectEmployee}
            onSelectAll={handleSelectAll}
          />
        ) : (
          <EmployeeCards 
            employees={filteredAndSortedEmployees}
            selectedEmployees={selectedEmployees}
            onSelectEmployee={handleSelectEmployee}
            onSelectAll={handleSelectAll}
          />
        )}
      </div>
    </div>
  );
};

// ========================
// PLACEHOLDER COMPONENTS (will be implemented in subsequent prompts)
// ========================

interface EmployeeViewProps {
  employees: Employee[];
  selectedEmployees: Set<string>;
  onSelectEmployee: (id: string) => void;
  onSelectAll: () => void;
}

const EmployeeGrid: React.FC<EmployeeViewProps> = ({ employees, selectedEmployees, onSelectEmployee, onSelectAll }) => {
  if (employees.length === 0) {
    return <EmptyState />;
  }

  return (
    <div>
      {/* Grid Controls */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 gap-4">
        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={employees.length > 0 && selectedEmployees.size === employees.length}
            onChange={onSelectAll}
            className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
          />
          <span className="text-sm text-gray-600 font-medium">
            Выбрать все ({employees.length})
          </span>
        </div>
        
        <div className="flex items-center gap-4 text-sm text-gray-500">
          <span>Сортировка применена</span>
          <button className="text-blue-600 hover:text-blue-800 font-medium transition-colors">
            Изменить порядок
          </button>
        </div>
      </div>
      
      {/* Employee Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
        {employees.map((employee) => (
          <EmployeeCard
            key={employee.id}
            employee={employee}
            selected={selectedEmployees.has(employee.id)}
            onSelect={onSelectEmployee}
          />
        ))}
      </div>
    </div>
  );
};

const EmployeeTable: React.FC<EmployeeViewProps> = () => (
  <div className="text-center py-16 border-2 border-dashed border-gray-300 rounded-xl">
    <div className="text-gray-400 text-6xl mb-4">📋</div>
    <h3 className="text-lg font-medium text-gray-900 mb-2">Табличный вид</h3>
    <p className="text-gray-500">Будет реализован в следующем промпте - подробная таблица с сортировкой и фильтрами</p>
  </div>
);

const EmployeeCards: React.FC<EmployeeViewProps> = () => (
  <div className="text-center py-16 border-2 border-dashed border-gray-300 rounded-xl">
    <div className="text-gray-400 text-6xl mb-4">📇</div>
    <h3 className="text-lg font-medium text-gray-900 mb-2">Карточный вид</h3>
    <p className="text-gray-500">Будет реализован в следующем промпте - компактные карточки сотрудников</p>
  </div>
);

interface EmployeeCardProps {
  employee: Employee;
  selected: boolean;
  onSelect: (id: string) => void;
}

const EmployeeCard: React.FC<EmployeeCardProps> = ({ employee, selected, onSelect }) => {
  const getStatusConfig = (status: Employee['status']) => {
    const configs = {
      active: { color: 'bg-green-100 text-green-800 border-green-200', text: 'Активен', dot: 'bg-green-500' },
      vacation: { color: 'bg-yellow-100 text-yellow-800 border-yellow-200', text: 'В отпуске', dot: 'bg-yellow-500' },
      probation: { color: 'bg-blue-100 text-blue-800 border-blue-200', text: 'Испытательный', dot: 'bg-blue-500' },
      inactive: { color: 'bg-gray-100 text-gray-800 border-gray-200', text: 'Неактивен', dot: 'bg-gray-400' },
      terminated: { color: 'bg-red-100 text-red-800 border-red-200', text: 'Уволен', dot: 'bg-red-500' }
    };
    return configs[status] || configs.inactive;
  };

  const getSkillLevelColor = (level: number) => {
    if (level >= 4) return 'bg-green-500';
    if (level >= 3) return 'bg-yellow-500';
    return 'bg-gray-400';
  };

  const getPerformanceColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-yellow-600';
    return 'text-red-600';
  };

  const statusConfig = getStatusConfig(employee.status);

  return (
    <div 
      className={`bg-white border rounded-xl hover:shadow-lg transition-all duration-200 cursor-pointer p-6 ${
        selected ? 'ring-2 ring-blue-500 border-blue-300 shadow-md' : 'border-gray-200 hover:border-gray-300'
      }`}
    >
      {/* Card Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={selected}
            onChange={(e) => {
              e.stopPropagation();
              onSelect(employee.id);
            }}
            className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
          />
          
          {/* Employee Photo with Status Indicator */}
          <div className="relative">
            <img
              src={employee.personalInfo.photo || 'https://i.pravatar.cc/150?img=1'}
              alt={`${employee.personalInfo.firstName} ${employee.personalInfo.lastName}`}
              className="w-16 h-16 rounded-full object-cover border-3 border-gray-100 shadow-sm"
            />
            <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white shadow-sm ${statusConfig.dot}`}></div>
          </div>
        </div>
        
        {/* Action Menu */}
        <div className="flex gap-1">
          <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Просмотр">
            <span className="text-lg">👁️</span>
          </button>
          <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Редактировать">
            <span className="text-lg">✏️</span>
          </button>
        </div>
      </div>
      
      {/* Employee Info */}
      <div className="space-y-3">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">
            {employee.personalInfo.firstName} {employee.personalInfo.lastName}
          </h3>
          <p className="text-sm text-gray-600 font-medium">{employee.workInfo.position}</p>
          <p className="text-xs text-gray-500 font-mono">{employee.employeeId}</p>
        </div>
        
        {/* Team and Manager */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full flex-shrink-0"
              style={{ backgroundColor: employee.workInfo.team.color }}
            ></div>
            <span className="text-sm text-gray-600 truncate">{employee.workInfo.team.name}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-lg">👤</span>
            <span className="text-xs text-gray-500 truncate">{employee.workInfo.manager}</span>
          </div>
        </div>
        
        {/* Status Badge */}
        <div>
          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${statusConfig.color}`}>
            {statusConfig.text}
          </span>
        </div>
        
        {/* Skills Preview */}
        <div className="space-y-2">
          <p className="text-xs text-gray-500 font-medium">Навыки:</p>
          <div className="space-y-1">
            {employee.skills.slice(0, 3).map((skill, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-xs text-gray-700 truncate flex-1">{skill.name}</span>
                <div className="flex gap-1 ml-2">
                  {[1, 2, 3, 4, 5].map(level => (
                    <div
                      key={level}
                      className={`w-2 h-2 rounded-full ${
                        level <= skill.level ? getSkillLevelColor(skill.level) : 'bg-gray-200'
                      }`}
                    ></div>
                  ))}
                </div>
              </div>
            ))}
            {employee.skills.length > 3 && (
              <p className="text-xs text-gray-500">+{employee.skills.length - 3} навыков</p>
            )}
          </div>
        </div>
        
        {/* Performance Metrics */}
        <div className="pt-3 border-t border-gray-100">
          <div className="grid grid-cols-2 gap-3 text-center">
            <div>
              <div className={`text-sm font-bold ${getPerformanceColor(employee.performance.qualityScore)}`}>
                {employee.performance.qualityScore}%
              </div>
              <div className="text-xs text-gray-500">Качество</div>
            </div>
            <div>
              <div className={`text-sm font-bold ${getPerformanceColor(employee.performance.adherenceScore)}`}>
                {employee.performance.adherenceScore}%
              </div>
              <div className="text-xs text-gray-500">Соблюдение</div>
            </div>
          </div>
          <div className="mt-2 text-center">
            <div className="text-sm font-medium text-gray-900">{employee.performance.callsPerHour}</div>
            <div className="text-xs text-gray-500">Звонков/час</div>
          </div>
        </div>
      </div>
    </div>
  );
};

const EmptyState: React.FC = () => (
  <div className="text-center py-16">
    <div className="text-gray-300 text-8xl mb-6">👥</div>
    <h3 className="text-xl font-semibold text-gray-900 mb-2">Сотрудники не найдены</h3>
    <p className="text-gray-500 mb-6 max-w-md mx-auto">
      Попробуйте изменить параметры поиска или фильтры, либо добавьте новых сотрудников в систему.
    </p>
    <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
      Добавить первого сотрудника
    </button>
  </div>
);

export default EmployeeListContainer;