// /Users/m/Documents/wfm/competitor/naumen/employee-management/src/App.tsx

import React from 'react';
import EmployeeListContainer from './components/EmployeeListContainer';
import './index.css';

// ========================
// MAIN DEMO APPLICATION
// Employee Management System - Chat 4 Implementation
// Based on Naumen reference designs with Chat 6 & Chat 3 patterns
// ========================

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Navigation */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">WFM</span>
                </div>
                <h1 className="text-xl font-semibold text-gray-900">
                  Workforce Management
                </h1>
              </div>
              
              <nav className="hidden md:flex items-center gap-1 ml-8">
                <a 
                  href="#" 
                  className="px-3 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg"
                >
                  Сотрудники
                </a>
                <a 
                  href="#" 
                  className="px-3 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Расписания
                </a>
                <a 
                  href="#" 
                  className="px-3 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Прогнозы
                </a>
                <a 
                  href="#" 
                  className="px-3 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Отчеты
                </a>
                <a 
                  href="#" 
                  className="px-3 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Заявки
                </a>
              </nav>
            </div>
            
            <div className="flex items-center gap-4">
              <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                <span className="text-lg">🔔</span>
              </button>
              <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                <span className="text-lg">⚙️</span>
              </button>
              <div className="flex items-center gap-3 pl-4 border-l border-gray-200">
                <img 
                  src="https://i.pravatar.cc/40?img=50" 
                  alt="Администратор"
                  className="w-8 h-8 rounded-full"
                />
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">Администратор</p>
                  <p className="text-xs text-gray-500">admin@company.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="flex items-center space-x-2">
              <li>
                <a href="#" className="text-gray-500 hover:text-gray-700 text-sm font-medium">
                  Главная
                </a>
              </li>
              <li>
                <span className="text-gray-400 mx-2">/</span>
                <span className="text-gray-900 text-sm font-medium">Сотрудники</span>
              </li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <EmployeeListContainer />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center">
                <span className="text-white font-bold text-xs">WFM</span>
              </div>
              <span className="text-sm text-gray-600">
                Workforce Management System v2.0
              </span>
            </div>
            
            <div className="flex items-center gap-6 text-sm text-gray-500">
              <span>Контакт-центр 1010</span>
              <span>|</span>
              <span>Employee Management Module</span>
              <span>|</span>
              <span>© 2024</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;