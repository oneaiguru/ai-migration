# utils/localization.py

from typing import Dict, Any

DEFAULT_LANGUAGE = 'ru'
TRANSLATIONS: Dict[str, Dict[str, str]] = {
    'ru': {
        'partner_already_exists': 'Партнер {partner_name} уже существует.',
        'rename_partner_hint': 'Чтобы переименовать выбранного партнера, отправьте сообщение в формате "/r Новое Имя".',
        'partner_added': 'Партнер {partner_name} добавлен.',
        'max_partners_reached': 'Достигнуто максимальное количество партнеров (5).',
        'unexpected_error_response': 'Произошла неожиданная ошибка. Пожалуйста, попробуйте позже.',
        'invalid_input_error': 'Недопустимый ввод. Пожалуйста, попробуйте снова.',
        'error_generating_referral_link': 'Произошла ошибка при генерации реферальной ссылки. Пожалуйста, попробуйте позже.',
        'error_getting_referral_status': 'Произошла ошибка при получении вашего реферального статуса. Пожалуйста, попробуйте позже.',
    
        'non_text_message_support': 'Данный тип сообщений пока не поддерживается. Пожалуйста, отправляйте только текстовые сообщения.',
        'english_message_received': 'Пожалуйста, используйте русский язык.\nPlease use Russian language.',
        'invalid_gender': 'Неверный выбор. Пожалуйста, выберите ваш пол: мужчина или женщина.',
        'welcome_message': 'Добро пожаловать в бот-советник по отношениям!',
        'enter_partner_name': 'Пожалуйста, введите имя вашего партнера (максимум 50 символов).',
        'discussion_start': 'Отлично! Теперь вы можете обсудить ваши отношения с {partner_name}.',
        'start_new_chat': 'Пожалуйста, начните новый разговор с помощью /new_chat.',
        'error_handling_message': 'Извините, произошла ошибка при обработке вашего сообщения.',
        'no_saved_partners': 'У вас пока нет сохраненных партнеров. Используйте /new_chat, чтобы начать.',
        'select_partner': 'Выберите партнера, введя соответствующий номер:\n{partner_list}',
        'current_discussion': 'Сейчас вы обсуждаете ваши отношения с {partner_name}.',
        'invalid_choice': 'Неверный выбор. Пожалуйста, попробуйте еще раз.',
        'enter_number': 'Пожалуйста, введите число.',
        'action_canceled': 'Действие отменено.',
        'character_limit_exceeded': 'Превышен лимит символов. Пожалуйста, сократите ваше сообщение.',
        'token_limit_reached': 'Вы достигли лимита токенов. Пожалуйста, пополните баланс для продолжения.',
        'feedback_request': 'Как вам этот ответ? Пожалуйста, оцените его:\n👍 - Полезно\n👎 - Не полезно',
        'feedback_thanks_positive': 'Спасибо за ваш положительный отзыв!',
        'feedback_request_details': 'Нам жаль это слышать. Не могли бы вы предоставить более подробную информацию о том, что мы могли бы улучшить?',
        'feedback_invalid_response': 'Пожалуйста, ответьте 👍 для полезного или 👎 для неполезного.',
        'feedback_thanks_detailed': 'Спасибо за ваш подробный отзыв. Мы используем его для улучшения нашего сервиса.',
        'balance_info': 'Ваш текущий баланс: {balance:.2f} токенов',
        'error_creating_profile': 'Произошла ошибка при создании профиля. Пожалуйста, перезапустите бот нажав /start и попробуйте еще раз, если ошибка повторяется, пожалуйста, свяжитесь с @Soul_Match_support',
        'error_adding_partner': 'Произошла ошибка при добавлении партнера. Пожалуйста, перезапустите бот нажав /start и попробуйте еще раз, если ошибка повторяется, пожалуйста, свяжитесь с @Soul_Match_support',
        'profile_setup_complete': 'Настройка профиля завершена. Теперь вы можете начать общение.',
        'ask_gender': 'Пожалуйста, выберите ваш пол:',
        'gender_man': 'Мужчина',
        'gender_woman': 'Женщина',
        'gender_not_specify': 'Не хочу указывать',
        'gender_recorded': '👋 Привет! Я здесь, чтобы помочь тебе с вопросами знакомств. Нужно придумать первое сообщение или найти идею для свидания? Вместе мы найдем решение! \n\n Просто задай вопрос в чат — я сразу предложу полезные советы. А если тебе нужна помощь в составлении сообщений, напиши: "Предложи варианты сообщений для..." — и я помогу придумать лучшее. \n\n Давай начнем, и помни: я всегда рядом, чтобы поддержать тебя в любой ситуации 😊',
        'gender_error': 'Произошла ошибка при сохранении вашего выбора. Пожалуйста, перезапустите бот нажав /start и попробуйте еще раз, если ошибка повторяется, пожалуйста, свяжитесь с @Soul_Match_support',
        'running_locally': 'Запуск в локальном режиме. Настройка SOCKS5 прокси.',
        'running_on_vps': 'Запуск на VPS. Прокси не используется.',
        'connection_error_chat': 'Ошибка подключения при инициализации Chat: {error}',
        'value_error_chat': 'Ошибка значения при инициализации Chat: {error}',
        'unexpected_error_chat': 'Неожиданная ошибка при нициализации Chat: {error}',
        'contact_info': 'Если у вас возникли вопросы или проблемы, пожалуйста, свяжитесь с нашей службой поддержки: @Soul_Match_support',
        'contact_info_updated': 'Контактная информация обновлена: {new_info}',
        'referral_link': 'Ваша реферальная ссылка: t.me/{bot_username}?start=ref_{code}',
        'feedback_statistics': 'Статистика отзывов:\nВсего отзывов: {total}\nПоложительных отзывов: {positive:.2f}%\nОтрицательных отзывов: {negative:.2f}%\nОсновные темы: {themes}',
        'error_feedback_stats': 'Ошибка при получении статистики отзывов: {error}',
        'error_fetching_feedback': 'Произошла ошибка при получении статистики отзывов. Пожалуйста, перезапустите бот нажав /start и попробуйте еще раз, если ошибка повторяется, пожалуйста, свяжитесь с @Soul_Match_support',
        'referral_bonus_applied': 'Реферальный бонус в размере {amount} применен для пользователя {user_id}',
        'validation_error': 'Ошибка валидации для пользователя {user_id}: {error}',
        'database_error': 'Ошибка базы данных для пользователя {user_id}: {error}',
        'ai_model_error': 'Ошибка AI модели для пользователя {user_id}: {error}',
        'unexpected_error': 'Неожиданная ошибка для пользователя {user_id}: {error}',
        'no_response_generated': 'К сожалению, я не смог сгенерировать ответ. Пожалуйста, попробуйте еще раз.',
        'default_response_unavailable': 'Стандартный механизм ответа недоступен.',
        'error_generating_response': 'Ошибка при генерации ответа: {error}',
        'error_processing_message': 'Извините, произошла ошибка при обработке вашего сообщения. Пожалуйста, попробуйте позже.',
        'unexpected_error_response': 'Произошла непредвиденная ошибка. Пожалуйста, перезапустите бот нажав /start и попробуйте еще раз, если ошибка повторяется, пожалуйста, свяжитесь с @Soul_Match_support',
        'feedback_prompt': 'Как вам этот ответ? Пожалуйста, оцените или дайте обратную связь.',
        'no_referrals_yet': 'Вы еще никого не пригласили. Используйте /referral, чтобы получить вашу реферальную ссылку!',
        'referral_status': 'Количество приглашенных вами пользователей: {count}. Сумма заработанных бонусов: {bonus:.2f}.',
        'feedback_prompt_general': 'Как вам этот ответ? Пожалуйста, оцените или дайте обратную связь.',
        'feedback_prompt_relationship_advice': 'Насколько полезным был этот совет по отношениям? Пожалуйста, оцените или дайте обратную связь.',
        'feedback_positive': '👍 Полезно',
        'feedback_negative': '👎 Не полезно',
        'feedback_received': 'Ваш отзыв получен.',
        'feedback_thank_you': 'Спасибо за ваш отзыв!',
        'invalid_feedback': 'Неверный отзыв. Пожалуйста, выберите 👍 или 👎.',
        'partner_set': 'Партнер {partner_name} успешно выбран.',
        'error_setting_partner': 'Произошла ошибка при установке партнера. Пожалуйста, попробуйте еще раз.',
        'partner_switched': 'Вы переключились на разговор с партнером {partner_name}.',
        'partner_not_found': 'Партнер с таким именем не найден. Пожалуйста, проверьте имя или добавьте нового партнера.',
        'error_switching_partner': 'Произошла ошибка при смене партнера. Пожалуйста, попробуйте еще раз.',
        'partner_list': 'Ваши партнеры:\n{partner_list}',
        'no_partners': 'У вас пока нет сохраненных партнеров. Используйте команду /set_partner, чтобы добавить нового партнера.',
        'error_listing_partners': 'Произошла ошибка при получении списка партнеров. Пожалуйста, попробуйте еще раз.',
        'no_active_partner': 'У вас нет выбранного партнера. Пожалуйста, используйте команду /p , чтобы выбрать партнера.',
        'enter_partner_name_to_remove': 'Пожалуйста, введите имя партнера, которого вы хотите удалить.',
        'error_removing_partner': 'Произошла ошибка при удалении партнера. Пожалуйста, попробуйте еще раз.',
        'partner_removed': 'Партнер {partner_name} успешно удален.',
        'partner_not_found_for_removal': 'Партнер с именем {partner_name} не найден.',
        'active_partner': 'Ваш выбранный партнер: {partner_name}',
        'error_getting_active_partner': 'Произошла ошибка при получении информации о выбранном партнере. Пожалуйста, попробуйте еще раз.',
        'invalid_action': 'Неверное действие. Пожалуйста, попробуйте еще раз.',
        'partner_added': 'Партнер №{partner_number} успешно добавлен.',
        'rename_usage': 'Использование: /r <номер партнера> <новое_имя>',
        'partner_renamed_success': 'Партнер успешно переименован на "{new_name}".',
        'partner_list_header': 'Ваши партнеры:',
        'add_partner_prompt': 'Добавление нового партнера.',
        'remove_partner_success': 'Партнер "{partner_name}" успешно удален.',
        'remove_partner_failure': 'Не удалось удалить партнера "{partner_name}". Пожалуйста, попробуйте еще раз.',
        'partner_limit_reached': 'Вы достигли максимального количества партнеров (5). Пожалуйста, удалите существующего партнера перед добавлением нового.',
        'invalid_partner_number': 'Неверный номер п��ртнера. Пожалуйста, попробуйте еще раз.',
        'partner_identifier': 'Партнер #{partner_name}',
        'unauthorized': 'У вас нет прав для выполнения этой команды.',
        'error_fetching_metrics': 'Произошла ошибка при получении метрик вовлеченности пользователей.',
        'error_fetching_trends': 'Произошла ошибка при получении тенденций отзывов.',
        'error_fetching_token_usage': 'Произошла ошибка при получении использования токенов.',
        'error_fetching_top_users': 'Произошла ошибка при получении топ пользователей по использованию токенов.',
        'invalid_date_range': 'Неверный диапазон дат. Пожалуйста, предоставьте начальную и конечную даты в формате ГГГГ-ММ-ДД.',
        'invalid_date_format': 'Неверный формат даты. Пожалуйста, используйте формат ГГГГ-ММ-ДД.',
        'add_partner_button': 'Добавить партнера',  
        'delete_current_partner': 'Удалить выбранного партнера',
        'active_partner_set': 'Партнер "{partner_name}" выбран, теперь вы можете начать общение о нем.',
        'partner_not_found': 'Партнер №{partner_number} не найден.',
        'remove_partner_failure': 'Не удалось удалить партнера "{partner_name}". Пожалуйста, попробуйте еще раз.',
        'invalid_action': 'Недопустимое действие. Пожалуйста, попробуйте еще раз.',
        'active': 'выбранный',
        'delete_active_partner': 'Удалить выбранного партнера',
        'set_active_partner_failure': 'Не удалось установить выбранного партнера. Пожалуйста, попробуйте еще раз.',
        'your_partners': 'Ваши партнеры:',
        'no_active_partners': 'У вас пока нет выбранного партнера.',
        'add_partner': 'Добавить партнера',
        'partner': 'Партнер',
        'invalid_partner_number': 'Неверный номер партнера. Пожалуйста, попробуйте еще раз.',
        'partner_not_found': 'Партнер с номером {partner_number} не найден.',
        'remove_partner_failure': 'Не удалось удалить партнера "{partner_name}". Пожалуйста, попробуйте еще раз.',
        'invalid_action': 'Неверное действие. Пожалуйста, попробуйте еще раз.',
        'error_handling_message': 'Извините, произошла ошибка при обработке вашего сообщения. Пожалуйста, попробуйте еще раз позже.',
        'max_partners_reached': 'Вы достигли максимального количества партнеров (5). Пожалуйста, удалите существующего партнера перед добавлением нового.',
        'rename_usage': 'Использовани: /r <номер партнера> <новое_имя>',
        'rename_partner_usage': 'Использование: /r <номер партнера> <новое_имя>',
        
        'partner_renamed': 'Партнер успешно переименован на "{new_name}".',
        'unexpected_error_response': 'Произошла непредвиденная ошибка. Пожалуйста, перезапустите бот нажав /start и попробуйте еще раз, если ошибка повторяется, пожалуйста, свяжитесь с @Soul_Match_support',
        'enter_new_partner_name': 'Пожалуйста, введите новое имя вашего партнера (максимум 50 символов).',
        'invalid_partner_name': 'Неверное имя партнера. Пожалуйста, используйте допустимые символы и не превышайте 50 символов.',
        'cancel': 'Действие отменено.',
        'partner_not_found': 'Партнер #{partner_number} не найден.',
        'partner_removed_success': 'Партнер "{partner_name}" успешно удален.',
        'remove_partner_failure': 'Не удалось удалить партнера "{partner_name}". Пожалуйста, попробуйте еще раз.',
        'invalid_partner_number': 'Неверный номер партнера. Пожалуйста, попробуйте еще раз.',
        'set_active_partner_failure': 'Не удалось установить активного партнера. Пожалуйста, попробуйте еще раз.',
        'active_partner_reassigned': 'Активный партнер был переустановлен на "{partner_name}".',
        'no_active_partners_left': 'Активных партнеров не осталось.',
        'partner_removed': 'Партнер "{partner_name}" был удален.',
        'select_chatbot': 'Пожалуйста, выберите чат-бота из списка ниже.',
        'response_generation_unavailable': 'Механизм генерации ответа недоступен.',
        'error_setting_active_partner': 'Произошла ошибка при установке активного партнера.',
        'error_renaming_partner': 'Произошла ошибка при переименовании партнера.',
        'partner_updated': 'Партнер {partner_name} обновлен.',
        'gender_default': 'Не хочу указывать', 
        'invalid_chatbot_id': 'Неверный ID чат-бота. Пожалуйста, попробуйте еще раз.',
        'no_active_chatbot': 'У вас нет активного чат-бота. Пожалуйста, создайте новый с помощью команды /new_chat.',
        'create_new_chatbot': 'Создать нового чат-бота.',
        'chatbot_selection_error': 'Ошибка выбора чат-бота. Пожалуйста, попробуйте еще раз.',
        'select_gender': 'Пожалуйста, выберите ваш пол:',
        'male': 'Мужчина',
        'female': 'Женщина',
        'other': 'Другой',
        'use_buttons_for_gender': 'Пожалуйста, используйте кнопки для выбора пола.',
        'manual_error': 'Ошибка при получении руководства пользователя.',
        'support_error': 'Ошибка при получении информации о поддержке.',
        'referral_link_error': 'Ошибка при генерации реферальной ссылки.',
        'referral_status_error': 'Ошибка при получении статуса рефералов.',
        'feedback_error': 'Ошибка при обработке отзыва.',
        'user_not_found': 'Пользователь не найден.',
        'rate_limit_exceeded': 'Превышен лимит запросов. Пожалуйста, попробуйте позже.',
        'new_chatbot_error': 'Ошибка при создании нового чат-бота. Пожалуйста, попробуйте еще раз.',
        'rename_partner_usage': 'Использование: /r <номер партнера> <новое_имя>',  # Added missing key
        'no_active_partner': 'У вас нет выбранного партнера. Пожалуйста, используйте команду /p , чтобы выбрать партнера.',  # Added missing key
        'database_error': 'Ошибка базы данных для пользователя {user_id}: {error}',  # Added missing key
        'unexpected_error_response': 'Произошла непредвиденная ошибка. Пожалуйста, перезапустите бот нажав /start и попробуйте еще раз, если ошибка повторяется, пожалуйста, свяжитесь с @Soul_Match_support',  # Added missing key
        'your_partners': 'Ваши партнеры:',  # Added missing key
        'no_active_partners': 'У вас пока нет выбранного партнера.',  # Added missing key
        'new_partner': 'Новый партнер',  # Added new key
        'delete': 'Удалить',  # Added new key
        'partner_menu_prompt': 'Выберите действие с партнером:',  # Added new key
        'partner_menu_error': 'Ошибка в меню партнера. Пожалуйста, попробуйте еще раз.',  # Added new key
        'partner_action_error': 'Ошибка при выполнении действия с партнером.',  # Added new key
        'start_error': 'Ошибка при запуске. Пожалуйста, попробуйте еще раз.',  # Added new key
        'new_partner_created': 'Новый партнер успешно создан.',
        'partner_activated': 'Партнер {partner_name} теперь активен.',
        'partner_deleted': 'Партнер {partner_name} был удален.',
        'invalid_input_message': 'Неверный формат ввода. Пожалуйста, попробуйте еще раз.',
    }
}

def get_text(key: str, language: str = DEFAULT_LANGUAGE, **kwargs: Any) -> str:
    try:
        text = TRANSLATIONS[language].get(key)
        if text is None:
            raise KeyError(f"Ключ перевода '{key}' не найден")
        return text.format(**kwargs) if kwargs else text
    except Exception as e:
        print(f"Ошибка при получении текста: {e}")
        return f"Ошибка перевода: {key}"

def get_text(key: str, language: str = DEFAULT_LANGUAGE, **kwargs: Any) -> str:
    try:
        text = TRANSLATIONS[language].get(key)
        if text is None:
            raise KeyError(f"Ключ перевода '{key}' не найден")
        return text.format(**kwargs) if kwargs else text
    except Exception as e:
        print(f"Ошибка при получении текста: {e}")
        return f"Ошибка перевода: {key}"

